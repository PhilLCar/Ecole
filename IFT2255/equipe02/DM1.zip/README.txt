1) dans le folder stats
   % svn log -v --xml > logfile.log

2) dans le folder stats
   % java -jar /path/to/statssvn.jar logfile.log ..

Ça devrait fonctionner
